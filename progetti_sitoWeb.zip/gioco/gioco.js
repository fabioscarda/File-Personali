var c = document.getElementById("myCanvas");
var ctx = c.getContext("2d");


drawButtonPlay();
setInterval(button, 100);


function button() {
    if ((mouseY < (buttonY + 50)) && (mouseY > (buttonY))) {
        if ((mouseX < (buttonX + 50)) && (mouseX > (buttonX))) {
            ctx.clear();
        }
    }
}

function drawButtonPlay() {
    var buttonX = 230;
    var buttonY = 230;

    ctx.beginPath();
    ctx.lineWidth = "1";
    ctx.strokeStyle = "black";
    ctx.rect(buttonX, buttonY, 100, 50);
    ctx.stroke();
    ctx.font = "20px Arial";
    ctx.fillText("play", buttonX + 30, buttonY + 30);
}